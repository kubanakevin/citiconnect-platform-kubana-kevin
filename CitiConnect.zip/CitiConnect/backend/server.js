import express from "express";
import mysql from "mysql";
import cors from "cors";
import session from "express-session";
import cookieParser from "cookie-parser";
import bodyParser from "body-parser";

const app = express();
app.use(
  cors({
    origin: ["http://localhost:3000"],
    methods: ["POST", "GET"],
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());
app.use(bodyParser.json());
app.use(
  session({
    secret: "secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      maxAge: 1000 * 60 * 60 * 24,
    },
  })
);

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "citiconnect",
});

app.get('/check-session', (req, res) => {
    if (req.session.user) {
      return res.json(req.session.user);
    } else {
      return res.json("No active session. Please log in.");
    }
});

app.post("/submit-complaint", (req, res) => {
  const sql =
    "INSERT INTO `complaints` (`citizen_name`, `nationalid`,`agency_name`,`category`,`subject`,`description`) VALUES (?)";
  const values = [
    req.body.fullname,
    req.body.nationalid,
    req.body.agencyname,
    req.body.category,
    req.body.subject,
    req.body.complaint,
  ];
  db.query(sql, [values], (err, data) => {
    if (err) return res.json("Fail to submit Complaint cs server error");
    return res.json(data);
  });
});


app.post("/login", (req, res) => {
  const sql = "SELECT * FROM users WHERE email = ? AND password = ?";
  const { username, password } = req.body;
  db.query(sql, [username, password], (err, result) => {
    if (err) return res.json("Error in Login server error");
    
    //  console.log(user.username)
    if (result.length > 0) {
      const user = result[0];
    req.session.user = {
      user_id: user.user_id,
      username: user.username,
      phone: user.phone,
      email: user.email,
      agency: user.agency
    };
      return res.json({ Login: true });
    } else {
      return res.json({ Login: false });
    }
  });
});

app.get('/complaints-submitted', (req, res) => {
    const sql = "SELECT * FROM complaints WHERE `status` = ? AND `agency_name` = ? ORDER BY complaint_id DESC"
    const agency = req.session.user.agency
    db.query(sql,['Received',agency], (err, data) => {
        if (err) return res.json("Error is fetching Complaint")
            return res.json(data)
    })
})

app.get('/complaints-solved', (req, res) => {
    const sql = "SELECT * FROM complaints WHERE `status` = ? AND `agency_name` = ? ORDER BY complaint_id DESC"
    const agency = req.session.user.agency
    db.query(sql,['Resolved',agency], (err, data) => {
        if (err) return res.json("Error is fetching Complaint")
            return res.json(data)
    })
})

app.get('/progress-complaints', (req, res) => {
    const sql = "SELECT * FROM complaints WHERE `status` = ? AND `agency_name` = ? ORDER BY complaint_id DESC"
    const agency = req.session.user.agency
    db.query(sql,['In Progress',agency], (err, data) => {
        if (err) return res.json("Error is fetching Complaint")
            return res.json(data)
    })
})

app.get('/rejected-complaints', (req, res) => {
    const sql = "SELECT * FROM complaints WHERE `status` = ? AND `agency_name` = ? ORDER BY complaint_id DESC"
    const agency = req.session.user.agency
    db.query(sql,['Closed',agency], (err, data) => {
        if (err) return res.json("Error is fetching Complaint")
            return res.json(data)
    })
})
// app.get('/solved-complaints', (req, res) => {
//     const sql = "SELECT * FROM complaints WHERE `status` = ? AND `agency_name` = ? ORDER BY complaint_id DESC"
//     const agency = req.session.user.agency
//     db.query(sql,['Resolved',agency], (err, data) => {
//         if (err) return res.json("Error is fetching Complaint")
//             return res.json(data)
//     })
// })

app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.json({ message: "Failed to log out" });
    res.clearCookie("connect.sid");
    res.json({ message: "Logged out successfully" });
  });
});

app.post('/register', (req, res) => {
    const sql = "INSERT INTO `users` (`username`,`email`, `phone` ,`agency`,`password`) VALUES(?)"
    const values = [
        req.body.username,
        req.body.email,
        req.body.phone,
        req.body.agency,
        req.body.password,
    ]
    db.query(sql, [values], (err, data) => {
        if (err) return res.json("Error in server")
            return res.json(data)
    })
})

app.get('/my-profile', (req, res) => {
    const sql = "SELECT * FROM users WHERE `user_id` = ?"
    const user_id = req.session.user.user_id
    db.query(sql, [user_id], (err, result) => {
        if (err) return res.json("error in server")
            return res.json(result[0])
    })
})

app.get('/accept-complaint/:id', (req, res) => {
  const complaintId = req.params.id;
  const updateSql = "UPDATE complaints SET status = 'In Progress' WHERE complaint_id = ?";
  db.query(updateSql, [complaintId], (updateErr, updateResult) => {
    if (updateErr) {
      console.error("Update error:", updateErr);
      return res.json("Error updating complaint");
    }
    if (updateResult.affectedRows === 0) {
      return res.status(404).json("Complaint not found");
    }
    const selectSql = "SELECT * FROM complaints WHERE complaint_id = ?";
    db.query(selectSql, [complaintId], (selectErr, result) => {
      if (selectErr) {
        console.error("Select error:", selectErr);
        return res.json("Error fetching complaint");
      }
      return res.json(result[0]); 
    });
  });
});
app.get('/change-complaint/:id', (req, res) => {
  const complaintId = req.params.id;
  // const updateSql = "UPDATE complaints SET status = 'Resolved' WHERE complaint_id = ?";
  // db.query(updateSql, [complaintId], (updateErr, updateResult) => {
  //   if (updateErr) {
  //     console.error("Update error:", updateErr);
  //     return res.json("Error updating complaint");
  //   }
  //   if (updateResult.affectedRows === 0) {
  //     return res.status(404).json("Complaint not found");
  //   }
    const selectSql = "SELECT * FROM complaints WHERE complaint_id = ?";
    db.query(selectSql, [complaintId], (selectErr, result) => {
      if (selectErr) {
        console.error("Select error:", selectErr);
        return res.json("Error fetching complaint");
      }
      return res.json(result[0]); 
    });
  });
// });

app.get('/solve-complaint/:id', (req, res) => {
  const complaintId = req.params.id;
  const selectSql = "SELECT * FROM complaints WHERE complaint_id = ?";

  db.query(selectSql, [complaintId], (err, result) => {
    if (err) {
      console.error("Select error:", err);
      return res.json("Error fetching complaint");
    }

    if (result.length === 0) {
      return res.status(404).json("Complaint not found");
    }

    return res.json(result[0]);
  });
});


app.post('/solves-complaint', (req, res) => {
  const { complaintId, nationalid, message } = req.body;

  const insertSql = "INSERT INTO responses (`complaint_id`, `responder_id`, `message`) VALUES (?, ?, ?)";
  const insertValues = [complaintId, nationalid, message];

  db.query(insertSql, insertValues, (insertErr, insertResult) => {
    if (insertErr) {
      console.error("Insert error:", insertErr);
      return res.json({ error: "Error inserting response" });
    }

    const updateSql = "UPDATE complaints SET status = 'Resolved' WHERE complaint_id = ?";
    db.query(updateSql, [complaintId], (updateErr, updateResult) => {
      if (updateErr) {
        console.error("Update error:", updateErr);
        return res.json({ error: "Error updating complaint status" });
      }

      if (updateResult.affectedRows === 0) {
        return res.status(404).json({ error: "Complaint not found" });
      }

      return res.json({ success: true, message: "Response saved and complaint resolved" });
    });
  });
});


app.post('/update-profile', (req, res) => {
  const { username, email, phone, password } = req.body;
  const user_id = req.session.user.user_id;

  const sql = "UPDATE users SET username = ?, email = ?, phone = ?, password = ? WHERE user_id = ?";
  db.query(sql, [username, email, phone, password, user_id], (err, result) => {
    if (err) return res.json({ error: "Update failed" });
    return res.json({ success: "Profile updated successfully" });
  });
});



app.get('/reject-complaint/:id', (req, res) => {
  const complaintId = req.params.id;
  const updateSql = "UPDATE complaints SET status = 'Closed' WHERE complaint_id = ?";
  db.query(updateSql, [complaintId], (updateErr, updateResult) => {
    if (updateErr) {
      console.error("Update error:", updateErr);
      return res.json("Error updating complaint");
    }
    if (updateResult.affectedRows === 0) {
      return res.status(404).json("Complaint not found");
    }
    const selectSql = "SELECT * FROM complaints WHERE complaint_id = ?";
    db.query(selectSql, [complaintId], (selectErr, result) => {
      if (selectErr) {
        console.error("Select error:", selectErr);
        return res.json("Error fetching complaint");
      }
      return res.json(result[0]); 
    });
  });
});

app.get('/count-received-complaints', (req, res) => {
  const sql = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'Received' AND agency_name = ?";
  const agency = req.session.user.agency
  db.query(sql,[agency], (err, result) => {
    if (err) {
      console.error("Error querying database:", err);
      return res.json({ error: "Server error" });
    }
    res.json({ receivedCount: result[0].count });
  });
});

app.get('/count-progress-complaints', (req, res) => {
  const sql = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'In Progress' AND agency_name = ?";
  const agency = req.session.user.agency
  db.query(sql,[agency], (err, result) => {
    if (err) {
      console.error("Error querying database:", err);
      return res.json({ error: "Server error" });
    }
    res.json({ progressCount: result[0].count });
  });
});

app.get('/count-rejected-complaints', (req, res) => {
  const sql = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'Closed' AND agency_name = ?";
  const agency = req.session.user.agency
  db.query(sql,[agency], (err, result) => {
    if (err) {
      console.error("Error querying database:", err);
      return res.json({ error: "Server error" });
    }
    res.json({ closedCount: result[0].count });
  });
});
app.get('/count-solved-complaints', (req, res) => {
  const sql = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'Resolved' AND agency_name = ?";
  const agency = req.session.user.agency
  db.query(sql,[agency], (err, result) => {
    if (err) {
      console.error("Error querying database:", err);
      return res.json({ error: "Server error" });
    }
    res.json({ solvedCount: result[0].count });
  });
});
app.get('/count-all-complaints', (req, res) => {
  const sql = "SELECT COUNT(*) AS count FROM complaints WHERE agency_name = ?";
  const agency = req.session.user.agency
  db.query(sql,[agency], (err, result) => {
    if (err) {
      console.error("Error querying database:", err);
      return res.json({ error: "Server error" });
    }
    res.json({ allCount: result[0].count });
  });
});

app.get('/update-complaint/:id', (req, res) => {
  const {idnum} = req.body
  const sql = "UPDATE complaints SET status = 'Resolved' WHERE complaint_id = ?";
  db.query(sql, [idnum], (err, result) => {
    if (err) {
      console.error("Error updating complaint:", err);
      return res.json({ error: "Database update failed" });
    }
    return res.json({ success: true, message: "Complaint updated" });
  });
});

app.post('/track-ticket', (req, res) => {
  const { complaint_id } = req.body;

  const sql1 = `
    SELECT 
      r.message, 
      r.responder_id, 
      r.complaint_id,
      c.citizen_name,
      c.nationalid,
      c.agency_name,
      c.category,
      c.subject,
      c.description,
      c.status
    FROM responses r
    JOIN complaints c ON r.complaint_id = c.complaint_id
    WHERE r.responder_id = ?
  `;

  const sql2 = `
    SELECT 
      NULL AS message,
      NULL AS responder_id,
      c.complaint_id,
      c.citizen_name,
      c.nationalid,
      c.agency_name,
      c.category,
      c.subject,
      c.description,
      c.status
    FROM complaints c
    WHERE c.nationalid = ?
  `;

  db.query(sql1, [complaint_id], (err, result1) => {
    if (err) {
      console.error(err);
      return res.json({ error: 'Database error' });
    }

    if (result1.length > 0) {
      return res.json({ found: true, ...result1[0] });
    }
    db.query(sql2, [complaint_id], (err, result2) => {
      if (err) {
        console.error(err);
        return res.json({ error: 'Database error' });
      }

      if (result2.length > 0) {
        return res.json({ found: true, ...result2[0] });
      }

      return res.json({ found: false });
    });
  });
});





app.listen(8081, () => {
  console.log("Server is running on port 8081");
});
