import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Complaint from "./pages/Complaint";
import TrackStatus from "./pages/TrackStatus";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import "@fortawesome/fontawesome-free/css/all.min.css";
import Submittedcomplaint from "./pages/SubmittedComplaint";
import Progresscomplaint from "./pages/ProgressComplaint";
import Profile from "./pages/Profile";
import Rejectedcomplaint from "./pages/RejectedComplaint";
import Register from "./pages/Register";
import Acceptcomplaint from "./pages/AcceptComplaint";
import Rejectcomplaint from "./pages/RejectComplaint";
import Solvecomplaint from "./pages/SolveComplaint";
import Solvedcomplaint from "./pages/SolvedComplaint";
import ThankYou from "./pages/Thankyou";
import Forgotpassword from './pages/ForgotPassword'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/submit-complaint" element={<Complaint />} />
          <Route path="/track-status" element={<TrackStatus />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route
            path="/submitted-complaints"
            element={<Submittedcomplaint />}
          />
          <Route path="/progress-complaints" element={<Progresscomplaint />} />
          <Route path="/rejected-complaints" element={<Rejectedcomplaint />} />
          <Route path="/accept-complaint/:id" element={<Acceptcomplaint />} />
          <Route path="/reject-complaint/:id" element={<Rejectcomplaint />} />
          <Route path="/solve-complaint/:id" element={<Solvecomplaint />} />
          <Route path="/solved-complaints" element={<Solvedcomplaint />} />
          <Route path="/my-profile" element={<Profile />} />
          <Route path="/register" element={<Register />} />
          <Route path="/thankyou" element={<ThankYou />} />
          <Route path="/forgot-password" element={<Forgotpassword />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
