import React from "react";
import { useNavigate } from "react-router-dom";
import Frontendheader from "./FrontendHeader";

function ThankYou() {
  const navigate = useNavigate();
  const handleBackHome = () => {
    navigate("/"); 
  };
  return (
    <div className="container text-center mt-5">
    <Frontendheader />
      <div className="card shadow-lg p-5 rounded-4" style={{marginTop: '10rem'}}>
        <div className="card-body">
          <h1 className="text-success mb-4"> Thank You!</h1>
          <p className="lead">
            Your Message withEmail has been received successfully. We appreciate your feedback!
          </p>
          <button className="btn btn-primary mt-3" onClick={handleBackHome}>
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}

export default ThankYou;
