import React, { useState } from "react";
import Frontendheader from "./FrontendHeader";
import axios from "axios";

const TrackStatus = () => {
  const [ticketId, setTicketId] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!ticketId) {
    setError(" Enter You National Id to Continue");
    return;
  }
    setError("");
    setResult(null); 
    axios
      .post("http://localhost:8081/track-ticket", { complaint_id: ticketId })
      .then((res) => {
        if (res.data.found) {
          setResult(res.data);
        } else {
          setError(" Complaint not found. Double check your input data");
        }
      })
      .catch((err) => {
        setError("System is in Maintenance. Please try again later.");
        console.error(err);
      });
  };

  return (
    <div className="container mt-5 pt-5 p-3">
      <Frontendheader />
      <h2 className="text-center mb-4">Track Complaint Status</h2>
      <div className="row justify-content-center">
        <div className="col-md-8">
          <form onSubmit={handleSubmit}>
            <div className="input-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Enter Complaint ID / Your National ID"
                value={ticketId}
                onChange={(e) => setTicketId(e.target.value)}
              />
              <button className="btn btn-primary" type="submit">
                Track
              </button>
            </div>
          </form>
          {error && (
            <div className="card gradient-card shadow-lg rounded-4 mt-3 p-5">
              <div className="alert alert-danger" role="alert">
                {error}
              </div>
            </div>
          )}
          {result && (
            <div className="card gradient-card shadow-lg rounded-4 mt-3">
              <div className="card-body">
                <p className="text-center">
                  <b>Your Complaint FeedBack</b>
                </p>
                <h5 className="card-title">
                  <b>Status: </b>
                  {result.status}
                </h5>
                <p className="card-text mt-2">
                  <b className="text-primary">Subject:</b> {result.subject}
                </p>
                <p className="card-text">
                  <b className="text-primary">Agency:</b> {result.agency_name}
                </p>
                <p className="card-text mt-2">
                  <b className="text-primary">Subject:</b> {result.description}
                </p>
                
                <hr />
                <p>
                  <strong className="text-primary">Latest Response:</strong>
                </p>
                <p>
                  {result?.message?.length > 0 ? (
                    result.message
                  ) : (
                    <b>
                      Waiting for response{" "}
                      <i className="fa fa-refresh fa-spin"></i>
                    </b>
                  )}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TrackStatus;
