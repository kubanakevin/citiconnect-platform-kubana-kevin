import React from "react";
import Frontendheader from "./FrontendHeader";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

function Register() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [agency, setAgency] = useState("");
  const [password, setPassword] = useState("");
  const [alert, setAlert] = useState({
    show: false,
    message: "",
    type: "success",
  });
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;
  function handleSubmit(event) {
    event.preventDefault();
    axios
      .post("http://localhost:8081/register", { username, email, phone, agency, password })
      .then((res) => {
        if (res.data) {
          setAlert({
            show: true,
            message: "Account Created Successfully Dirrecting...",
            type: "success",
          });
          setTimeout(() => {
            setAlert((prev) => ({ ...prev, show: false }));
            navigate("/login");
          }, 2000);
        } else {
          setAlert({
            show: true,
            message: "Account Not Created Try Again Later",
            type: "danger",
          });
        }
        console.log(res);
        if (!username || !password || !phone || !agency) {
          setAlert({
            show: true,
            message: "Fail to create account!,  Fill all field to continue and try again later",
            type: "danger",
          });
        }
      })
      .catch((err) => {
        setAlert({
        show: true,
        message: "System is in Maintenance. Please try again later.",
        type: "danger",
      });
        console.log(err)});
  }
  return (
    <div  className="p-4">
      <Frontendheader />
      <br />
      <br />
      <div className="card gradient-card shadow-lg rounded-4 mx-auto col-lg-5 p-5 mt-5 shadow">
        <h4 className="text-center">Create Account</h4>
        {alert.show && (
          <div
            className={`alert alert-${alert.type} alert-dismissible fade show text-center`}
            role="alert"
          >
            {alert.message}
            <button
              type="button"
              className="btn-close"
              onClick={() => setAlert({ ...alert, show: false })}
            ></button>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>
              <i class="fa fa-user"></i> Username
            </label>
            <input
              type="text"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i class="fa fa-envelope"></i> Email
            </label>
            <input
              type="email"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i class="fa fa-phone"></i> Phone
            </label>
            <input
              type="tel"
              id=""
              className="form-control"
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i className="fa fa-building"></i> Agency Name
            </label>
            <select
              className="form-control"
              onChange={(e) => setAgency(e.target.value)}
              // required
            >
              <option></option>
              <option value="Local Government">Local Government</option>
              <option value="Rwanda Utilities Regulatory Authority (RURA)">
                Rwanda Utilities Regulatory Authority (RURA)
              </option>
              <option value="Rwanda National Police (RNP)">
                Rwanda National Police (RNP)
              </option>
              <option value="Rwanda Development Board (RDB)">
                Rwanda Development Board (RDB)
              </option>
              <option value="Ministry of Health">Ministry of Health</option>
              <option value="Ministry of Education">
                Ministry of Education
              </option>
              <option value="(REG)">(REG)</option>
              <option value="(WASAC)">(WASAC)</option>
            </select>
          </div>
          <div className="form-group">
            <label>
              <i class="fa fa-lock"></i> Password
            </label>
            <input
              type="password"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button className="btn btn-primary mt-4 col-lg-12 col-md-12 col-sm-12">
            <i class="fa fa-user-plus"></i> Register
          </button>
          <Link to="/login">
            <p className="mt-2" style={{ textAlign: "right" }}>
              <i className="fa fa-sign-in"></i> Login If You alread have account
            </p>
          </Link>
        </form>
      </div>
    </div>
  );
}
export default Register;
