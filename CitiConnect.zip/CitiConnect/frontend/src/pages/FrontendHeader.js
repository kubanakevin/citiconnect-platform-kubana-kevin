import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link } from 'react-router-dom'
import Logoimg from './images/icon.png'

function Frontendheader() {
  return (
    <div className="header">
      <Navbar expand="lg" className=" text-hover fixed-top" style={{backgroundColor: '#1E3A8A'}}>
        <Container>
          <Navbar.Brand href="/"><img src={Logoimg}  style={{width: '4rem'}}/><span className="text-white" style={{fontSize: '30px'}}>CitiConnect</span></Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ms-auto">
              <Nav.Link href="/" className="text-white"><i className="fa fa-home"></i> Home</Nav.Link>
              <Nav.Link href="/track-status" className="text-white"><i className="fa fa-search"></i> Track Status</Nav.Link>
              <Nav.Link href="/submit-complaint" className="text-white nav-link text-dark bg-primary rounded px-3 py-2"><i className="fa fa-file"></i> Submit Complaint</Nav.Link>
              
              <Link to="/login" className="text-white btn btn-warning ms-2"><i className="fa fa-sign-in"></i> Login</Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}
export default Frontendheader;
