import React from "react";
import Frontendheader from "./FrontendHeader";
import BgImage from "./images/background.jpg";
import Trash from "./images/trash.jpg";
import Bulb from "./images/bulb.jpeg";
import Water from "./images/water.png";
import Issues from "./images/issues.png";
import Logoimg from './images/icon.png'
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="Home">
      <Frontendheader />
      <img src={BgImage} className="mt-5" />
      <div className="services">
        <h4 className="text-center mt-4">Complaints popular</h4>
        <div className="row p-5" style={{}}>
          <div className="card gradient-card shadow-lg rounded-4 col-lg-3 ms-5 mb-5 shadow text-center p-3">
            <div className="photo">
              <img src={Trash} style={{ width: "10rem" }} alt="Image" />
            </div>
            <h4 className="text-primary">
              Waste <br />
              Management
            </h4>
          </div>
          <div className="card gradient-card shadow-lg rounded-4 col-lg-3  mb-5 shadow ms-5 text-center p-3">
            <div className="photo">
              <img src={Bulb} style={{ width: "10rem" }} alt="Image" />
            </div>
            <h4 className="text-primary">Electricity</h4>
          </div>
          <div className="card gradient-card shadow-lg rounded-4 col-lg-3  mb-5 shadow ms-5 text-center p-3">
            <div className="photo">
              <img src={Water} style={{ width: "10rem" }} alt="Image" />
            </div>
            <h4 className="text-primary">
              Water <br />
              Supply
            </h4>
          </div>
          <div className="card gradient-card shadow-lg rounded-4 col-lg-3  mb-5 shadow ms-5 text-center p-3">
            <div className="photo">
              <img src={Issues} style={{ width: "10rem" }} alt="Image" />
            </div>
            <h4 className="text-primary">
              Other <br />
              Issues
            </h4>
          </div>
        </div>
      </div>
      <div className="complaints mb-4">
        <div
          className="row text-white"
          style={{ padding: "1rem 1rem 1rem 5rem", backgroundColor: "#1E3A8A" }}
        >
          <div className="comp p-5 text-center col-lg-3">
            <h1>1,200</h1>
            <h5>Total complaint submitted</h5>
          </div>
          <div className="comp p-5 text-center col-lg-3">
            <h1>1,000</h1>
            <h5>Resolved complaints</h5>
          </div>
          <div className="comp p-5 text-center col-lg-3">
            <h1>13</h1>
            <h5>Active Agencies Involved</h5>
          </div>
        </div>
      </div>
      <div className="container">
        <div class="container mt-5 p-4">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="card shadow rounded-4">
                <div class="card-body">
                  <h3 class="card-title text-center mb-4">
                    <i class="fa fa-envelope text-primary"></i> Contact Us
                  </h3>
                  <form action="https://formsubmit.co/kubanakevin@gmail.com" method="POST">
                    <div class="mb-3">
                      <label for="name" class="form-label">
                        <i class="fa fa-user"></i> Full Name
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="name"
                        placeholder="Enter your full name"
                        name="name"
                        required
                      />
                    </div>

                    <div class="mb-3">
                      <label for="email" class="form-label">
                        <i class="fa fa-envelope"></i> Email address
                      </label>
                      <input
                        type="email"
                        class="form-control"
                        id="email"
                        name="email"
                        placeholder="you@example.com"
                        required
                      />
                    </div>

                    <div class="mb-3">
                      <label for="subject" class="form-label">
                        <i class="fa fa-tag"></i> Subject
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        id="subject"
                        name="subject"
                        placeholder="Subject of your message"
                        required
                      />
                    </div>

                    <div class="mb-3">
                      <label for="message" class="form-label">
                        <i class="fa fa-comment"></i> Message
                      </label>
                      <textarea
                        class="form-control"
                        id="message"
                        rows="5"
                        name="message"
                        placeholder="Type your message here..."
                        required
                      ></textarea>
                      <input type="hidden" name="_captcha" value="false" />
                      <input type="hidden" name="_next" value="http://localhost:3000/thankyou" />
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                      <i class="fa fa-paper-plane"></i> Send Message
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="footer col-lg-12">
        <footer class=" text-\ pt-5 pb-4" style={{backgroundColor: '#f8f9fa'}}>
          <div class="container text-md-left">
            <div class="row">
              <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4">
                <h6 class=" fw-bold mb-4">
                  <img src={Logoimg}  style={{width: '4rem'}}/><span className="text-white" style={{fontSize: '30px'}}></span>
                  <span style={{fontSize: '30px'}}>CitiConnect</span>
                </h6>
                <p>
                  Web platform that empowers citizens to voice their concerns or feedback about 
                  public services. It facilitates streamlined communication between citizens
                   and government institutions 
                  {/* by categorizing, routing, and tracking complaints through a user-friendly system */}
                </p>
              </div>
              <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                <h6 class="text-uppercase fw-bold mb-4">Links</h6>
                <p>
                  <a href="#" class="text-reset text-decoration-none">
                   <i className="fa fa-home"></i> Home
                  </a>
                </p>
                <p>
                  <Link to='/track-status' class="text-reset text-decoration-none">
                  <i className="fa fa-search"></i>  Track Status
                  </Link>
                </p>
                <p>
                  <Link to='/submit-complaint'  class="text-reset text-decoration-none">
                   <i className="fa fa-file"></i> Submit Complaint
                  </Link>
                </p>
                <p>
                  <Link to='/login' class="text-reset text-decoration-none">
                   <i className="fa fa-sign-in"></i> Login
                  </Link>
                </p>
              </div>
              <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                <p>
                  <i class="fa fa-house me-2"></i> Kigali, Rwanda
                </p>
                <p>
                  <i class="fa fa-envelope me-2"></i> citiconnect@gmail.com
                </p>
                <p>
                  <i class="fa fa-phone me-2"></i> +250 789 000 123
                </p>
                <p>
                  <i class="fab fa-whatsapp me-2 text-success"></i>+250 788 804 113
                </p>
              </div>
              <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4 text-center">
                <h6 class="text-uppercase fw-bold mb-4">Follow Us</h6>
                <a href="#" class="me-3 text-reset">
                  <i class="fab fa-facebook-f"></i>
                </a>
                <a href="#" class="me-3 text-reset">
                  <i class="fab fa-twitter"></i>
                </a>
                <a href="#" class="me-3 text-reset">
                  <i class="fab fa-linkedin"></i>
                </a>
                <a href="#" class="me-3 text-reset">
                  <i class="fab fa-instagram"></i>
                </a>
              </div>
            </div>
          </div>

          <div class="text-center p-3 mt-4 border-top border-light">
            © 2025 CitiConnect. All Rights Reserved. | Designed And Created by{" "}
            <a href="mailto:kubanakevin@gmail.com" style={{textDecoration: 'none'}}><strong>KUBANA Kevin</strong></a> 
          </div>
        </footer>
      </div>
    </div>
  );
}

export default Home;
