import React, { useState } from "react";
import Frontendheader from "./FrontendHeader";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

function ResetPassword() {
  const [email, setEmail] = useState("");
  const [alert, setAlert] = useState({ show: false, message: "", type: "success" });
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!email) {
      setAlert({ show: true, message: "Email must not be empty", type: "danger" });
      return;
    }
    if (email) {
      setAlert({ show: true, message: "Password Reseted! Check your Email", type: "success" });
      return;
    }

  };

  return (
    <div className="p-4">
      <Frontendheader />
      <div className="card gradient-card shadow-lg rounded-4 mx-auto col-lg-5 p-5 shadow-lg" style={{marginTop: '6rem'}}>
        <h4 className="text-center">Reset Password</h4>
        {alert.show && (
          <div className={`alert alert-${alert.type} alert-dismissible fade show text-center`} role="alert">
            {alert.message}
            <button type="button" className="btn-close" onClick={() => setAlert({ ...alert, show: false })}></button>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>
              <i className="fa fa-envelope"></i> Email
            </label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            //   required
            />
          </div>
          <button type="submit" className="btn btn-success mt-4 w-100">
            <i className="fa fa-unlock"></i> Reset Password
          </button>
          <p className="mt-2"><Link to='/login' style={{textDecoration: 'none',color: '#000'}}><i className="fa fa-sign-in"></i> back to Login</Link></p>
        </form>
      </div>
    </div>
  );
}

export default ResetPassword;
