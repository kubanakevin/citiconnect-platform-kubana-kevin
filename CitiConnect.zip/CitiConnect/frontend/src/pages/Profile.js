import React from "react";
import { Link, useNavigate } from "react-router-dom";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Logoimg from "./images/icon.png";
import Avator from "./images/avator.png";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";

function Dashboard() {
  const [userData, setUserdata] = useState([]);
  const [citizen, setCitizen] = useState({
    username: "",
    email: "",
    phone: "",
    password: "",
  });
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  axios.defaults.withCredentials = true;
  useEffect(() => {
    axios
      .get("http://localhost:8081/check-session")
      .then((res) => {
        if (res.data) {
          setUserdata(res.data);
          // axios
          //   .get("http://localhost:8081/my-profile")
          //   .then((res) => {
          //     setCitizen(res.data);
          //   })
          //   .catch((err) => console.log(err));
        } else {
          navigate("/");
        }
        console.log(res);
      })
      .catch((err) => console.log(err));
  }, []);
  const handleLogout = () => {
    axios
      .get("http://localhost:8081/logout")
      .then((res) => {
        navigate("/login");
      })
      .catch((err) => {
        console.error("Logout failed:", err);
      });
  };
  useEffect(() => {
    axios
      .get("http://localhost:8081/my-profile")
      .then((res) => {
        setCitizen(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  function handleSubmit(event) {
    event.preventDefault();
    axios
      .post("http://localhost:8081/update-profile")
      .then((res) => {
        console.log(res);
      })
      .catch((err) => console.log(err));
  }

  return (
    <div>
      <Navbar
        expand="lg"
        className=" text-hover fixed-top col-lg-12 col-sm-12 col-md-12"
        style={{ backgroundColor: "#1E3A8A" }}
      >
        {/* <Container> */}
        <Navbar.Brand href="#home">
          <img src={Logoimg} style={{ width: "4rem" }} />
          <span className="text-white" style={{ fontSize: "30px" }}>
            CitiConnect
          </span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link href="/notification" className="text-warning">
              <i className="fa fa-bell"></i>
            </Nav.Link>
            <Nav.Link href="/my-profile" className="text-white">
              <i className="fa fa-user"></i>
            </Nav.Link>
            <button
              onClick={handleLogout}
              className="btn btn-danger ms-3"
              style={{ marginRight: "6rem" }}
            >
              <i className="fa fa-sign-out me-2"></i> Logout
            </button>
          </Nav>
        </Navbar.Collapse>
        {/* </Container> */}
      </Navbar>
      <div className="d-flex fixed-top" style={{ marginTop: "5.20rem" }}>
        <aside
          className=" text-white vh-100 p-3 sidebar"
          style={{ backgroundColor: "#f0f2f5" }}
        >
          <ul className="nav flex-column">
            <div className="card p-3 d-flex flex-row align-items-center gap-3 shadow-sm mb-3">
              <div className="text-center">
                <img
                  src={Avator}
                  alt="User"
                  className="rounded-circle"
                  width="60"
                  height="60"
                  style={{ width: "4rem" }}
                />
                <h6 className="mb-1">{userData.username}</h6>
                <small className="text-primary">{userData.agency}</small>
              </div>
            </div>

            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-primary rounded px-3 py-2"
                to="/dashboard"
              >
                <i className="fa fa-home"></i> Home
              </Link>
            </li>

            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/submitted-complaints"
              >
                <i className="fa fa-file"></i> Sub Complaints
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/progress-complaints"
              >
                <i className="fa fa-spinner fa-spin"></i> Pro Complaints
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/rejected-complaints"
              >
                <i className="fa fa-times "></i> Rej Complaints
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/solved-complaints"
              >
                <i className="fa fa-check "></i> Sol Complaints
              </Link>
            </li>
          </ul>
        </aside>
        <div
          className="flex-grow-1 vh-100 p-5 ms-3 col-lg-8"
          style={{ overflowX: "scroll", overflowY: "scroll" }}
        >
          {/* <div className="row"> */}
          <div className="row p-5 shadow-lg rounded-5">
            <div className=" col-lg-4">
              <h3>My Profile</h3>
              <img
                src={Avator}
                className="col-lg-6"
                style={{ border: "2px solid grey", borderRadius: "250px" }}
              />
            </div>
            <div className="col-lg-8">
              <h3>Information</h3>
              <h6>
                <b className="text-primary">Username:</b> {userData.username}
              </h6>
              <h6>
                <b className="text-primary">Email:</b> {userData.email}
              </h6>
              <h6>
                <b className="text-primary">Phone:</b> {userData.phone}
              </h6>
              <h6>
                <b className="text-primary">Agency Name:</b> {userData.agency}
              </h6>
              <Link
              // to="/update-profile-info"
              // className="btn btn-primary col-lg-6"
              >
                {" "}
                <Button variant="primary" onClick={handleShow}>
                  Update Your Info
                </Button>
              </Link>
            </div>
            <div className="bg p-5">
              <h5>Background</h5>
              <p>
                I have background in responsible for reviewing and analyzing submitted complaints to determine facts and ensure proper follow-up
              </p>
            </div>
            <Modal show={show} onHide={handleClose}>
              <Modal.Header closeButton>
                <Modal.Title>Update your Information</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label>Username</label>
                    {/* <input type="text" value={citizen.user_id} oncha /> */}
                    <input
                      type="text"
                      value={citizen.username}
                      onChange={(e) =>
                        setCitizen({ ...citizen, username: e.target.value })
                      }
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      value={citizen.email}
                      onChange={(e) =>
                        setCitizen({ ...citizen, email: e.target.value })
                      }
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <label>Phone</label>
                    <input
                      type="text"
                      value={citizen.phone}
                      onChange={(e) =>
                        setCitizen({ ...citizen, phone: e.target.value })
                      }
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      value={citizen.password}
                      onChange={(e) =>
                        setCitizen({ ...citizen, password: e.target.value })
                      }
                      className="form-control"
                    />
                  </div>
                  {/* <button type="submit" className="btn btn-primary mt-3">Update Profile</button> */}
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                      Close
                    </Button>
                    <Button
                      variant="primary"
                      type="submit"
                      onClick={handleClose}
                    >
                      Save Changes
                    </Button>
                  </Modal.Footer>
                </form>
              </Modal.Body>
            </Modal>
          </div>
          {/* </div> */}
        </div>
      </div>
    </div>
  );
}
export default Dashboard;
