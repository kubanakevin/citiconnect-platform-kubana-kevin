import React from "react";
import Frontendheader from "./FrontendHeader";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [alert, setAlert] = useState({
    show: false,
    message: "",
    type: "success",
  });
  const navigate = useNavigate();
  axios.defaults.withCredentials = true

  function handleSubmit(event) {
  event.preventDefault();

  if (!username || !password) {
    setAlert({
      show: true,
      message: "Email / Password must not be empty",
      type: "danger",
    });
    return;
  }

  axios
    .post("http://localhost:8081/login", { username, password })
    .then((res) => {
      if (res.data.Login) {
        setAlert({
          show: true,
          message: "Login Successfully. Redirecting...",
          type: "success",
        });
        setTimeout(() => {
          setAlert((prev) => ({ ...prev, show: false }));
          navigate("/dashboard");
        }, 2000);
      } else {
        setAlert({
          show: true,
          message: "Invalid Credentials Email/Password",
          type: "danger",
        });
      }
    })
    .catch((err) => {
      console.log(err);
      setAlert({
        show: true,
        message: "System is in Maintenance. Please try again later.",
        type: "danger",
      });
    });
}

  return (
    <div className="p-4">
      <Frontendheader />
      <br />
      <br />
      <div className="card gradient-card shadow-lg rounded-4 mx-auto col-lg-5 p-5 mt-5 shadow">
        <h4 className="text-center">Log into System</h4>
        {alert.show && (
          <div
            className={`alert alert-${alert.type} alert-dismissible fade show text-center`}
            role="alert"
          >
            {alert.message}
            <button
              type="button"
              className="btn-close"
              onClick={() => setAlert({ ...alert, show: false })}
            ></button>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>
              <i class="fa fa-user"></i> Username
            </label>
            <input
              type="email"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setUsername(e.target.value)}
              // required
            />
          </div>
          <div className="form-group">
            <label>
              <i class="fa fa-lock"></i> Password
            </label>
            <input
              type="password"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setPassword(e.target.value)}
              // required
            />
          </div>

          <button className="btn btn-primary mt-4 col-lg-12 col-md-12 col-sm-12">
            <i class="fa fa-sign-in"></i> Login
          </button>
          <Link to='/forgot-password' style={{textDecoration: 'none',color: '#000'}}><p className="mt-2" style={{textAlign: 'right'}}><i className="fa fa-brain"></i> Forgot Password</p></Link>
          <Link to='/register' style={{textDecoration: 'none',color: '#000'}}><p className="mt-2" style={{textAlign: 'right'}}><i className="fa fa-user-plus"></i> Create New Account</p></Link>
        </form>
      </div>
    </div>
  );
}
export default Login;
