import React from "react";
import { Link, useNavigate } from "react-router-dom";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Logoimg from "./images/icon.png";
import Avator from "./images/avator.png";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";

function Solvedcomplaint() {
  const [userData, setUserdata] = useState([]);
  const [citizen, setCitizen] = useState([]);
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;
  useEffect(() => {
    axios
      .get("http://localhost:8081/check-session")
      .then((res) => {
        if (res.data) {
          setUserdata(res.data);
          axios
            .get("http://localhost:8081/complaints-solved")
            .then((res) => {
              setCitizen(res.data);
            })
            .catch((err) => console.log(err));
        } else {
          navigate("/");
        }

        console.log(res);
      })
      .catch((err) => {
        navigate("/login");
        console.log(err);
      });
  }, []);
  const handleLogout = () => {
    axios
      .get("http://localhost:8081/logout")
      .then((res) => {
        navigate("/login");
      })
      .catch((err) => {
        console.error("Logout failed:", err);
      });
  };
  axios
    .get("http://localhost:8081/accept-complaint/:id")
    .then((res) => {
      setCitizen(res.data);
    })
    .catch((err) => console.log(err));
  return (
    <div>
      <Navbar
        expand="lg"
        className=" text-hover fixed-top col-lg-12 col-sm-12 col-md-12"
        style={{ backgroundColor: "#1E3A8A" }}
      >
        <Navbar.Brand href="#home">
          <img src={Logoimg} style={{ width: "4rem" }} />
          <span className="text-white" style={{ fontSize: "30px" }}>
            CitiConnect
          </span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link href="/notification" className="text-warning">
              <i className="fa fa-bell"></i>
            </Nav.Link>
            <Nav.Link href="/my-profile" className="text-white">
              <i className="fa fa-user"></i>
            </Nav.Link>
            <button
              onClick={handleLogout}
              className="btn btn-danger ms-3"
              style={{ marginRight: "6rem" }}
            >
              <i className="fa fa-sign-out me-2"></i> Logout
            </button>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
      <div className="d-flex fixed-top" style={{ marginTop: "5.20rem" }}>
        <aside
          className=" text-white vh-100 p-3 sidebar"
          style={{ backgroundColor: "#f0f2f5" }}
        >
          <ul className="nav flex-column">
            <div className="card p-3 d-flex flex-row align-items-center gap-3 shadow-sm mb-3">
              <div className="text-center">
                <img
                  src={Avator}
                  alt="User"
                  className="rounded-circle"
                  width="60"
                  height="60"
                  style={{ width: "4rem" }}
                />
                <h6 className="mb-1">{userData.username}</h6>
                <small className="text-primary">{userData.agency}</small>
              </div>
            </div>

            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/dashboard"
              >
                <i className="fa fa-home"></i> Home
              </Link>
            </li>

            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/submitted-complaints"
              >
                <i className="fa fa-file"></i> Sub Complaints
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/progress-complaints"
              >
                <i className="fa fa-spinner fa-spin"></i> Pro Complaints
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-white rounded px-3 py-2"
                to="/rejected-complaints"
              >
                <i className="fa fa-times "></i> Rej Complaints
              </Link>
            </li>
            <li className="nav-item mb-2">
              <Link
                className="nav-link text-dark bg-primary rounded px-3 py-2"
                to="/solved-complaints"
              >
                <i className="fa fa-check "></i> Sol Complaints
              </Link>
            </li>
          </ul>
        </aside>
        <div
          className="flex-grow-1 p-3 vh-100"
          style={{ overflowX: "scroll", overflowY: "scroll" }}
        >
          <p>Solved Complaints</p>
          <table className="table table-hover table-sprited col-lg-12">
            <thead className="table-dark">
              <tr>
                <th>#</th>
                <th>Citizen Name</th>
                <th>National Id</th>
                <th>Agency Name</th>
                <th>Category</th>
                <th>Subject</th>
                <th>Description</th>
                {/* <th>Status</th> */}
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {citizen.length > 0 ? (
                citizen.map((complaint, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{complaint.citizen_name}</td>
                    <td>{complaint.nationalid}</td>
                    <td>{complaint.agency_name}</td>
                    <td>{complaint.category}</td>
                    <td>{complaint.subject}</td>
                    <td>{complaint.description}</td>
                    {/* <td>{complaint.status}</td> */}
                    <td>
                      <Link>
                        <i className="fa fa-sms text-success" title="Add Message addition"></i>
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="9" className="text-center text-danger">
                    No Submitted complaints found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
export default Solvedcomplaint;
