import React from "react";
import Frontendheader from "./FrontendHeader";
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Complaint() {
  const [fullname, setFullname] = useState("");
  const [nationalid, setNationalid] = useState("");
  const [agencyname, setAgencyname] = useState("");
  const [category, setCategory] = useState("");
  const [subject, setSubject] = useState("");
  const [complaint, setComplaint] = useState("");
  const navigate = useNavigate();
  const [alert, setAlert] = useState({
    show: false,
    message: "",
    type: "success",
  });
  function handleSubmit(event) {
    event.preventDefault();
    if (!fullname || !nationalid || !agencyname || !category || !subject || !complaint) {
      setAlert({
        show: true,
        message: "All Field must not be empty!, Fill all to continue",
        type: "danger",
      });
      return;
    }
    axios
      .post("http://localhost:8081/submit-complaint", {
        fullname,
        nationalid,
        agencyname,
        category,
        subject,
        complaint,
      })
      .then((res) => {
        console.log(res);
        setAlert({
          show: true,
          message: "Your complaint Submitted successfully ",
          type: "success",
        });
        setTimeout(() => {
          setAlert((prev) => ({ ...prev, show: false }));
          navigate("/");
        }, 3000);
      })
      .catch((err) => {
        console.log(err);
        setAlert({
          show: true,
          message: "Your Complain Not Submitted try again",
          type: "danger",
        });
      });
  }

  return (
    <div  className="p-4">
      <Frontendheader />
      <br />
      <br />
      <div className="card gradient-card shadow-lg rounded-4 mx-auto col-lg-5 p-5 mt-5 shadow">
        <h4 className="text-center">Submit Your Complaint Here</h4>
        {alert.show && (
          <div
            className={`alert alert-${alert.type} alert-dismissible fade show text-center`}
            role="alert"
          >
            {alert.message}
            <button
              type="button"
              className="btn-close"
              onClick={() => setAlert({ ...alert, show: false })}
            ></button>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>
              <i className="fa fa-user"></i> Full Names
            </label>
            <input
              type="text"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setFullname(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i className="fa fa-file-contract"></i> National ID
            </label>
            <input
              type="text"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setNationalid(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i className="fa fa-building"></i> Agency Name
            </label>
            <select
              className="form-control"
              onChange={(e) => setAgencyname(e.target.value)}
            >
              <option></option>
              <option value="Local Government">Local Government</option>
              <option value="Rwanda Utilities Regulatory Authority (RURA)">
                Rwanda Utilities Regulatory Authority (RURA)
              </option>
              <option value="Rwanda National Police (RNP)">
                Rwanda National Police (RNP)
              </option>
              <option value="Rwanda Development Board (RDB)">
                Rwanda Development Board (RDB)
              </option>
              <option value="Ministry of Health">Ministry of Health</option>
              <option value="Ministry of Education">
                Ministry of Education
              </option>
              <option value="(REG)">(REG)</option>
              <option value="(WASAC)">(WASAC)</option>
            </select>
          </div>
          <div className="form-group">
            <label>
              <i className="fa fa-layer-group"></i> Category
            </label>
            <input
              type="text"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setCategory(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i className="fa fa-book"></i> Subject
            </label>
            <input
              type="text"
              name=""
              id=""
              className="form-control"
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>
              <i class="fa fa-comment-dots"></i> Complaint
            </label>
            <textarea
              className="form-control"
              onChange={(e) => setComplaint(e.target.value)}
            />
          </div>
          <button className="btn btn-primary mt-4 col-lg-12 col-md-12 col-sm-12">
            <i class="fa fa-paper-plane"></i> Submit
          </button>
        </form>
      </div>
    </div>
  );
}
export default Complaint;
